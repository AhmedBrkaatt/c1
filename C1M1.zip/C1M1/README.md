/* Add Author and Project Details here */
ahmed barakat 
this project is a basic calculation of a given array
